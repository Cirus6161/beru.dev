<?php
/**
 * REST lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['error'] = 'خطأ!';
$_lang['rest.err_class_remove'] = 'حدث خطأ أثناء محاولة إزالة [[+class_key]]';
$_lang['rest.err_class_save'] = 'حدث خطأ أثناء محاولة حفظ [[+class_key]]';
$_lang['rest.err_field_ns'] = '[[+field]]غير محدد!';
$_lang['rest.err_field_required'] = 'هذا الحقل مطلوب.';
$_lang['rest.err_fields_required'] = 'الحقول التالية مطلوبة: [[+fields]]';
$_lang['rest.err_obj_nf'] = '[[+class_key]]غير موجود!';
