<?php
/**
 * System Events English lexicon topic
 *
 * @language en
 * @package modx
 * @subpackage lexicon
 */
$_lang['clear'] = 'Limpiar';
$_lang['error_log'] = 'Historial de Errores';
$_lang['error_log_desc'] = 'Aquí está el historial de errores de MODX Revolution:';
$_lang['error_log_download'] = 'Descargar Historial de Errores ([[+size]])';
$_lang['error_log_too_large'] = 'El historial de errores en <em>[[+name]]</em> es demasiado largo para ser desplegado. Puedes descargarlo utilizando el botón de descarga.';
$_lang['system_events'] = 'Eventos del Sistema';
$_lang['priority'] = 'Prioridad';