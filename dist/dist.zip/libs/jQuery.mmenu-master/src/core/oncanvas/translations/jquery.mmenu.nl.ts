(function( $ ) {

	var _PLUGIN_ = 'mmenu';

	$[ _PLUGIN_ ].i18n({
		'Menu': 'Menu'
	});

})( jQuery );